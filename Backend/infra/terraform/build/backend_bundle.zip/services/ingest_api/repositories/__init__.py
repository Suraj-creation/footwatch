"""Ingest repository implementations."""
