"""Query repository implementations."""
